import pandas as pd
import matplotlib.pyplot as plt
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Function to strip double quotes from a string
def strip_double_quotes(s):
    if isinstance(s, str):
        return s.strip('"')
    else:
        return s

# Function to analyze gender distribution and save plot as PNG
def analyze_and_save_gender_distribution(df):
    gender_counts = df['GENDER'].value_counts()
    gender_counts.plot(kind='bar', color='skyblue', edgecolor='black')
    plt.xlabel('Gender')
    plt.ylabel('Count')
    plt.title('Gender Distribution')
    plt.grid(True)
    plt.savefig(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\img\gender_distribution.png")
    plt.close()

# Function to analyze marital status distribution and save plot as PNG
def analyze_and_save_marital_status_distribution(df):
    marital_counts = df['MARITAL'].value_counts()
    marital_counts.plot(kind='bar', color='skyblue', edgecolor='black')
    plt.xlabel('Marital Status')
    plt.ylabel('Count')
    plt.title('Marital Status Distribution')
    plt.grid(True)
    plt.savefig(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\img\marital_state_distribution.png")
    plt.close()

# Function to analyze race distribution and save plot as PNG
def analyze_and_save_race_distribution(df):
    race_counts = df['RACE'].value_counts()
    race_counts.plot(kind='bar', color='skyblue', edgecolor='black')
    plt.xlabel('Race')
    plt.ylabel('Count')
    plt.title('Race Distribution')
    plt.grid(True)
    plt.savefig(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\img\race_distribution.png")
    plt.close()

# Function to handle file change events
class FileChangeHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith('.csv'):
            df = pd.read_csv("files/`patients`.csv")
            analyze_and_save_gender_distribution(df)
            analyze_and_save_marital_status_distribution(df)
            analyze_and_save_race_distribution(df)

# Create a file system event handler
file_change_handler = FileChangeHandler()

# Create a watchdog observer
observer = Observer()
observer.schedule(file_change_handler, path='.', recursive=False)
observer.start()

# Read the CSV file and analyze the data
df = pd.read_csv("files/`patients`.csv")
analyze_and_save_gender_distribution(df)
analyze_and_save_marital_status_distribution(df)
analyze_and_save_race_distribution(df)

try:
    while True:
        time.sleep(60)
        df = pd.read_csv("files/`patients`.csv")
        analyze_and_save_gender_distribution(df)
        analyze_and_save_marital_status_distribution(df)
        analyze_and_save_race_distribution(df)
except KeyboardInterrupt:
    observer.stop()
observer.join()