import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time

# Function to update plot and save as image
def update_plot_and_save():
    try:
        # Read CSV file 'medications.csv'
        df = pd.read_csv("files/`medications`.csv")

        # Group by medication and count the number of occurrences
        medication_counts = df['DESCRIPTION'].value_counts().head(5)

        # Plot top 5 medications
        plt.figure(figsize=(10, 6))
        sns.barplot(x=medication_counts.index, y=medication_counts.values, palette='viridis')
        plt.xlabel('Medication')
        plt.ylabel('Count')
        plt.title('Top 5 Medications Used')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()

        # Save plot as image
        plt.savefig(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\img\top_5_medications.png")  # Save image in 'static' directory

    except Exception as e:
        print("Error:", e)

# Initial plot and save
update_plot_and_save()

# Check for changes in CSV file every minute and update the plot
while True:
    try:
        time.sleep(60)  # Check every minute
        update_plot_and_save()
    except KeyboardInterrupt:
        break